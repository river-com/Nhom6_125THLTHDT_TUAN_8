public class Test {
    public static void main(String[] args) {
    quanLy ql = new quanLy();
    Sachgiaotrinh sachGT = new Sachgiaotrinh(200, 2018, 2,"A1", "Toan hoc");  
    SachNovel sachNv = new SachNovel(150, true, 5, "B2", "Truyen Kieu");
    ql.themSach(sachGT);
    ql.themSach(sachNv);
    ql.hienthidanhSach();
    kiemke kiemKe = sachGT;
    System.out.println("Kiem tra ton kho sach giao trinh:" + kiemKe.KiemTraTonKho(40));
    kiemKe.capNhapViTri("A1-05");
}
}
