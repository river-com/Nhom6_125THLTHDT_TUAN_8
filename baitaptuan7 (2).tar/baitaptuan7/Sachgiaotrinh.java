public class Sachgiaotrinh extends Sach  {
    private double namxb;
    private int soLuong;
    private String viTri;
    public Sachgiaotrinh(double giacoban, double namxb, int soLuong, String viTri, String tenSach){
        super(giacoban, tenSach);
        this.namxb=namxb;
        this.soLuong=soLuong;
        this.viTri=viTri;
    }
    public void set_namxb(double namxb){{
        this.namxb=namxb;
    }}
    public double get_namxb(){
        return namxb;
    }
    public void set_soLuong(int soLuong){
        this.soLuong=soLuong;
    }
    public int get_soLuong(){
        return soLuong;
    }
    public void set_viTri(String viTri){
        this.viTri=viTri;
    }
    public String get_viTri(){
        return viTri;
    }
    @Override
    public double tinhgiaban(){{
        return getter()+(5*(2025-get_namxb()));
    }}
    @Override
    public String toString(){
        return "Ten sach GT: " + get_tenSach() + ", nam xuat ban:" + get_namxb() + ", vi tri:" + get_viTri() + ", so luong: " + get_soLuong() ;
    }
@Override
public String KiemTraTonKho(int soluongtoithieu) {
    if(get_soLuong()>=soluongtoithieu){
    return "Vẫn còn sách giao trình trong kho";
    }else{
    return "Hết sách giao trình trong kho";
    }
    }  
@Override
public void capNhapViTri(String viTriMoi){
    this.viTri=viTriMoi;
    System.out.println("Vi tri moi cua sach" + get_tenSach() + "ten la: " + get_viTri());
}
}



