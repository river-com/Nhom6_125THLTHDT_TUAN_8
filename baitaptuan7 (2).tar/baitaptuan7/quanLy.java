import java.util.ArrayList;
public class quanLy {
    private ArrayList <Sach> danhSach = new ArrayList<>();
    public void themSach(Sach sach){
        danhSach.add(sach);
    }
    public void hienthidanhSach(){
        for(Sach sach:danhSach){
            System.out.println("Thong tin sach:"+ sach.toString());
            System.out.println("Gia ban uoc tinh là:" + sach.tinhgiaban()+"000 VND");
        }

    }
}
