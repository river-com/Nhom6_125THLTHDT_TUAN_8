public interface IGiaBan {
    double tinhgiaban();
}
