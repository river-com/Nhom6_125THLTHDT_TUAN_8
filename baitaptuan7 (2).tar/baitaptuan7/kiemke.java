public interface kiemke {

    
String KiemTraTonKho(int soluongtoithieu);
void capNhapViTri(String vitriMoi);    
}
