public class SachNovel extends Sach {
    private boolean origin;
    private int soLuong;
    private String viTri;
    public SachNovel (double giacoban, boolean origin, int soLuong, String viTri, String tenSach){
        super(giacoban, tenSach);
        this.origin=origin;
        this.soLuong=soLuong;
        this.viTri=viTri;
    }
    public void set_origin(boolean origin){
        this.origin=origin;
    }
    public boolean get_origin(){
        return origin;
    }
    public void set_soLuong(int soLuong){
        this.soLuong=soLuong;
    }
    public int get_soLuong(){
        return soLuong;
    }
    public void set_viTri(String viTri){
        this.viTri=viTri;
    }   
    public String get_viTri(){
        return viTri;
    }
    @Override
    public double tinhgiaban(){
        if (origin==true){
            return getter()+15;
        }else{
            return getter();
        }
    }
    @Override
    public String toString(){
        return "Ten sach novel: " + get_tenSach() + ", Vi tri: " + get_viTri() + ", so luong: " + get_soLuong() ;
    }
    @Override
    public String KiemTraTonKho(int soluongtoithieu) {
        if(get_soLuong()>=soluongtoithieu){
            return "Vẫn còn sách novel trong kho";
        }else{
            return "Hết sách novel trong kho";
        }   
    }
    @Override
    public void capNhapViTri(String vitriMoi) {
        this.viTri=vitriMoi;
        System.out.println("Vi tri moi cua sach" + get_tenSach() + "ten la: " + get_viTri());

    }    
}
