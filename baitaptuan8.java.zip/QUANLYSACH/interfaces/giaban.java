package interfaces;

public interface IGiaBan {
    double tinhGiaBan();
}
