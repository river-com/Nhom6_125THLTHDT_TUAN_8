package interfaces;

import entities.Sach;

import java.util.List;

public interface IQuanLySach {
    void themSach(Sach sach);
    Sach timKiemSach(String maSach);
    boolean xoaSach(String maSach);
    void hienThiDanhSach();
}
