package ui;

import entities.*;
import interfaces.IQuanLySach;
import services.QuanLySachImpl;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IQuanLySach quanLy = new QuanLySachImpl();
        int luaChon;

        do {
            System.out.println("\n===== MENU QUẢN LÝ SÁCH =====");
            System.out.println("1. Thêm sách");
            System.out.println("2. Hiển thị danh sách");
            System.out.println("3. Tìm kiếm sách");
            System.out.println("4. Xóa sách");
            System.out.println("0. Thoát");
            System.out.print("Chọn: ");
            luaChon = sc.nextInt();
            sc.nextLine();

            switch (luaChon) {
                case 1:
                    System.out.print("Nhập loại sách (1: Giáo trình, 2: Tiểu thuyết): ");
                    int loai = sc.nextInt(); sc.nextLine();
                    System.out.print("Mã sách: "); String ma = sc.nextLine();
                    System.out.print("Tiêu đề: "); String ten = sc.nextLine();
                    System.out.print("Tác giả: "); String tg = sc.nextLine();
                    System.out.print("Giá cơ bản: "); double gia = sc.nextDouble();
                    System.out.print("Số lượng: "); int sl = sc.nextInt(); sc.nextLine();
                    System.out.print("Vị trí: "); String vt = sc.nextLine();

                    if (loai == 1) {
                        System.out.print("Môn học: ");
                        String mon = sc.nextLine();
                        quanLy.themSach(new SachGiaoTrinh(ma, ten, tg, gia, sl, vt, mon));
                    } else {
                        System.out.print("Thể loại: ");
                        String tl = sc.nextLine();
                        quanLy.themSach(new SachTieuThuyet(ma, ten, tg, gia, sl, vt, tl));
                    }
                    break;

                case 2:
                    quanLy.hienThiDanhSach();
                    break;

                case 3:
                    System.out.print("Nhập mã sách cần tìm: ");
                    String maTim = sc.nextLine();
                    Sach sach = quanLy.timKiemSach(maTim);
                    if (sach != null) System.out.println(sach);
                    else System.out.println("❌ Không tìm thấy sách!");
                    break;

                case 4:
                    System.out.print("Nhập mã sách cần xóa: ");
                    String maXoa = sc.nextLine();
                    if (!quanLy.xoaSach(maXoa)) System.out.println("❌ Không tìm thấy sách!");
                    break;

                case 0:
                    System.out.println("👋 Thoát chương trình!");
                    break;
            }

        } while (luaChon != 0);
    }
}
