package QuanLySach;

// Giao dien kiem ke kho
public interface IKiemKe {
    boolean kiemTraTonKho(int soLuongToiThieu);
    void capNhatViTri(String viTriMoi);
}
