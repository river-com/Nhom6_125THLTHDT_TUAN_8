package QuanLySach;

// Lop con SachTieuThuyet ke thua tu Sach
public class SachTieuThuyet extends Sach {
    private String theLoai;
    private boolean laSeries;

    public SachTieuThuyet(String tieuDe, String tacGia, double giaCoBan, int soLuong, String viTri, String theLoai, boolean laSeries) {
        super(tieuDe, tacGia, giaCoBan, soLuong, viTri);
        this.theLoai = theLoai;
        this.laSeries = laSeries;
    }

    @Override
    public double tinhGiaBan() {
        return giaCoBan * 1.5; // Tieu thuyet loi nhuan 50%
    }

    @Override
    public boolean kiemTraTonKho(int soLuongToiThieu) {
        return soLuong >= soLuongToiThieu;
    }

    @Override
    public void capNhatViTri(String viTriMoi) {
        this.viTri = viTriMoi;
        System.out.println("Da chuyen sach " + tieuDe + " den khu vuc: " + viTriMoi);
    }

    @Override
    public String toString() {
        return "[Tieu thuyet] " + super.toString() +
               ", The loai: " + theLoai +
               ", La series: " + (laSeries ? "Co" : "Khong") +
               ", Gia ban: " + tinhGiaBan();
    }
}
