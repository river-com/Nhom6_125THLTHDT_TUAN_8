public class SachGiaoTrinh extends Sach {
    private String monHoc;

    public SachGiaoTrinh(String tieuDe, String tacGia, double giaCoBan, int soLuong, String viTri, String monHoc) {
        super(tieuDe, tacGia, giaCoBan, soLuong, viTri);
        this.monHoc = monHoc;
    }

    public String getMonHoc() { return monHoc; }
    public void setMonHoc(String monHoc) { this.monHoc = monHoc; }

    @Override
    public double tinhGiaBan() {
        // Ví dụ: giá bán = giá cơ bản + 10%
        return getGiaCoBan() * 1.10;
    }

    @Override
    public boolean kiemTraTonKho(int soLuongToiThieu) {
        return getSoLuong() >= soLuongToiThieu;
    }

    @Override
    public void capNhatViTri(String viTriMoi) {
        setViTri(viTriMoi);
        System.out.println("Đã chuyển sách '" + getTieuDe() + "' đến khu vực: " + viTriMoi);
    }

    @Override
    public String toString() {
        return "[Giáo Trình] " + super.toString() + ", Môn học: " + monHoc +
               ", Giá bán: " + tinhGiaBan();
    }
}
