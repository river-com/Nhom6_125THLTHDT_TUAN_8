public class SachTieuThuyet extends Sach {
    private String theLoai;

    public SachTieuThuyet(String tieuDe, String tacGia, double giaCoBan, int soLuong, String viTri, String theLoai) {
        super(tieuDe, tacGia, giaCoBan, soLuong, viTri);
        this.theLoai = theLoai;
    }

    public String getTheLoai() { return theLoai; }
    public void setTheLoai(String theLoai) { this.theLoai = theLoai; }

    @Override
    public double tinhGiaBan() {
        // Ví dụ: giá bán = giá cơ bản + 20%
        return getGiaCoBan() * 1.20;
    }

    @Override
    public boolean kiemTraTonKho(int soLuongToiThieu) {
        return getSoLuong() >= soLuongToiThieu;
    }

    @Override
    public void capNhatViTri(String viTriMoi) {
        setViTri(viTriMoi);
        System.out.println("Đã chuyển sách '" + getTieuDe() + "' đến khu vực: " + viTriMoi);
    }

    @Override
    public String toString() {
        return "[Tiểu Thuyết] " + super.toString() + ", Thể loại: " + theLoai +
               ", Giá bán: " + tinhGiaBan();
    }
}
