import java.util.List;

public interface IQuanLySach {
    void themSach(Sach sach);
    Sach timKiemSach(String tieuDe);
    void xoaSach(String tieuDe);
    void hienThiDanhSach();
    List<Sach> getDanhSach();
}
