import java.util.Scanner;

public class bai8 {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        IQuanLySach quanLy = new QuanLySachImpl();

        int choice;
        do {
            System.out.println("\n===== MENU QUẢN LÝ SÁCH =====");
            System.out.println("1. Thêm sách giáo trình");
            System.out.println("2. Thêm sách tiểu thuyết");
            System.out.println("3. Hiển thị danh sách");
            System.out.println("4. Tìm kiếm sách");
            System.out.println("5. Xóa sách");
            System.out.println("0. Thoát");
            System.out.print("👉 Chọn: ");
            choice = sc.nextInt();
            sc.nextLine();

            switch (choice) {
                case 1:
                    System.out.print("Nhập tiêu đề: ");
                    String td1 = sc.nextLine();
                    System.out.print("Nhập tác giả: ");
                    String tg1 = sc.nextLine();
                    System.out.print("Nhập giá cơ bản: ");
                    double gcb1 = sc.nextDouble();
                    System.out.print("Nhập số lượng: ");
                    int sl1 = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nhập vị trí: ");
                    String vt1 = sc.nextLine();
                    System.out.print("Nhập môn học: ");
                    String mh = sc.nextLine();
                    quanLy.themSach(new SachGiaoTrinh(td1, tg1, gcb1, sl1, vt1, mh));
                    break;

                case 2:
                    System.out.print("Nhập tiêu đề: ");
                    String td2 = sc.nextLine();
                    System.out.print("Nhập tác giả: ");
                    String tg2 = sc.nextLine();
                    System.out.print("Nhập giá cơ bản: ");
                    double gcb2 = sc.nextDouble();
                    System.out.print("Nhập số lượng: ");
                    int sl2 = sc.nextInt();
                    sc.nextLine();
                    System.out.print("Nhập vị trí: ");
                    String vt2 = sc.nextLine();
                    System.out.print("Nhập thể loại: ");
                    String tl = sc.nextLine();
                    quanLy.themSach(new SachTieuThuyet(td2, tg2, gcb2, sl2, vt2, tl));
                    break;

                case 3:
                    quanLy.hienThiDanhSach();
                    break;

                case 4:
                    System.out.print("Nhập tiêu đề cần tìm: ");
                    String tktd = sc.nextLine();
                    Sach s = quanLy.timKiemSach(tktd);
                    if (s != null)
                        System.out.println("🔍 Tìm thấy: " + s);
                    else
                        System.out.println("⚠️ Không tìm thấy sách!");
                    break;

                case 5:
                    System.out.print("Nhập tiêu đề cần xóa: ");
                    String xoaTd = sc.nextLine();
                    quanLy.xoaSach(xoaTd);
                    break;

                case 0:
                    System.out.println("👋 Thoát chương trình.");
                    break;

                default:
                    System.out.println("❌ Lựa chọn không hợp lệ!");
            }
        } while (choice != 0);
    }
}
